-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 19, 2018 at 04:38 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `MegaNews`
--

-- --------------------------------------------------------

--
-- Table structure for table `grupo`
--

CREATE TABLE `grupo` (
  `idGrupo` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `nivel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grupo`
--

INSERT INTO `grupo` (`idGrupo`, `nome`, `nivel`) VALUES
(1, 'Editor', 1),
(2, 'Membro', 0),
(3, 'Moderador', 2),
(4, 'Dono', 3);

-- --------------------------------------------------------

--
-- Table structure for table `postagem`
--

CREATE TABLE `postagem` (
  `idPostagem` int(11) NOT NULL,
  `exibir` char(1) NOT NULL,
  `titulo` varchar(50) NOT NULL,
  `descricao` varchar(300) NOT NULL,
  `texto` varchar(2000) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `data` date NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `postagem`
--

INSERT INTO `postagem` (`idPostagem`, `exibir`, `titulo`, `descricao`, `texto`, `idUsuario`, `data`, `foto`) VALUES
(12, 'S', 'Postagem 2 Teste', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis quam sed libero efficitur scelerisque. Proin ac purus nec orci sollicitudin fringilla. Sed finibus non nulla at facilisis. Curabitur imperdiet pharetra ultricies. Mauris sed augue vulputate, commodo enim at, pharetra velit. Duis tincid', 'sdajsdioasjdoiasdjsaiodjsadiojsadiosajiosajdsaiodjsaiodjsaodi', 27, '2018-07-05', '05a8ec1e15d8e635a03c8e35ad53ecd0.jpg'),
(13, 'S', 'Novo jogo do Spider-Man anunciado', 'O novo game do Homem-Aranha, exclusivo de PlayStation 4 e chamado apenas de Spider-Man, serÃ¡ lanÃ§ado em 7 de setembro de 2018.', 'No vÃ­deo eles falam sobre como vocÃª estarÃ¡ jogando como um Homem-Aranha mais experiente, aquele que anda por Manhattan â€œcom estilo e confianÃ§aâ€. Eles queriam fazer um AmigÃ£o da VizinhanÃ§a que Ã© sagaz e confiante em suas habilidades, e Ã© capaz de alternar facilmente entre teias de tiro, balanÃ§ando ao redor, e em combate corpo a corpo. Os desenvolvedores usam os termos â€œvelocidadeâ€, â€œestiloâ€, â€œfluxoâ€ e â€œfluidezâ€ para descrever seus objetivos para os movimentos do Teioso. TambÃ©m no vÃ­deo, os desenvolvedores discutem como, embora o Homem-Aranha seja mais antigo e mais refinado, esta ainda Ã© uma histÃ³ria de azarÃ£o que verÃ¡ o personagem superando as probabilidades de ganhar o dia.', 26, '2018-07-05', '8669664eebb5ff87d2ae5863e9661a01.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

CREATE TABLE `usuario` (
  `idUsuario` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `idGrupo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`idUsuario`, `nome`, `login`, `senha`, `foto`, `idGrupo`) VALUES
(16, 'teste12', 'test123', '12345678', '', 2),
(26, 'joao', 'leal', '12345678', '', 2),
(27, 'victor', 'victorsouza02', '10021997', '70f9dcb1980f501783e1b724196119dc.jpg', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `grupo`
--
ALTER TABLE `grupo`
  ADD PRIMARY KEY (`idGrupo`);

--
-- Indexes for table `postagem`
--
ALTER TABLE `postagem`
  ADD PRIMARY KEY (`idPostagem`),
  ADD KEY `idUsuario` (`idUsuario`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`idUsuario`),
  ADD KEY `idGrupo` (`idGrupo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `grupo`
--
ALTER TABLE `grupo`
  MODIFY `idGrupo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `postagem`
--
ALTER TABLE `postagem`
  MODIFY `idPostagem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idUsuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `postagem`
--
ALTER TABLE `postagem`
  ADD CONSTRAINT `postagem_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`);

--
-- Constraints for table `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`idGrupo`) REFERENCES `grupo` (`idGrupo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
