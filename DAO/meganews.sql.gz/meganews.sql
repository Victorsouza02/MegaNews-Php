-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 31-Jul-2018 às 00:17
-- Versão do servidor: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `meganews`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `grupo`
--

CREATE TABLE `grupo` (
  `idGrupo` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `nivel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `grupo`
--

INSERT INTO `grupo` (`idGrupo`, `nome`, `nivel`) VALUES
(1, 'Editor', 1),
(2, 'Membro', 0),
(3, 'Moderador', 2),
(4, 'Dono', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `postagem`
--

CREATE TABLE `postagem` (
  `idPostagem` int(11) NOT NULL,
  `exibir` char(1) NOT NULL,
  `titulo` varchar(50) NOT NULL,
  `descricao` varchar(300) NOT NULL,
  `texto` varchar(2000) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `data` date NOT NULL,
  `foto` varchar(255) NOT NULL,
  `contagem` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `postagem`
--

INSERT INTO `postagem` (`idPostagem`, `exibir`, `titulo`, `descricao`, `texto`, `idUsuario`, `data`, `foto`, `contagem`) VALUES
(14, 'S', 'Receita de Pudim', 'Receita de Pudim', '<h3><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"https://truffle-assets.imgix.net/84cnzp0itw1q_4ghu77ocikC4uacEQSGOKe_pudim-de-leite-condensado-facil_landscapeThumbnail_pt.jpeg\" width=\"465\" height=\"262\" /></h3>\r\n<h3 style=\"text-align: left;\">INGREDIENTES</h3>\r\n\r\nCalda:\r\n\r\n<div>1 x&iacute;cara (ch&aacute;) de a&ccedil;&uacute;car</div>\r\n\r\nPudim:\r\n\r\n<div style=\"text-align: left;\">1 Leite MO&Ccedil;A&reg; (lata ou caixinha)</div>\r\n<div style=\"text-align: left;\">2 medidas (da lata) de Leite L&iacute;quido NINHO Forti+ Integral</div>\r\n<div style=\"text-align: left;\">3 ovos</div>\r\n<div style=\"text-align: left;\">&nbsp;</div>\r\n<div>\r\n<h3>MODO DE PREPARO</h3>\r\n\r\nCalda:\r\nEm uma panela de fundo largo, derreta o a&ccedil;&uacute;car at&eacute; ficar dourado. Junte meia x&iacute;cara (ch&aacute;) de &aacute;gua quente e mexa com uma colher. Deixe ferver at&eacute; dissolver os torr&otilde;es de a&ccedil;&uacute;car e a calda engrossar. Forre com a calda uma forma com furo central (19 cm de di&acirc;metro) e reserve.\r\nPudim:\r\nEm um liquidificador, bata todos os ingredientes do pudim e despeje na forma reservada. Cubra com papel-alum&iacute;nio e leve ao forno m&eacute;dio (180&deg;C), em banho-maria com &aacute;gua quente, por cerca de 1 hora e 30 minutos. Depois de frio, leve para gelar por cerca de 6 horas. Desenforme e sirva a seguir.\r\nDICAS:\r\n- &Eacute; importante que a &aacute;gua utilizada no banho-maria esteja quente, para melhor cozimento do pudim.<br />- &Eacute; essencial que o pudim seja preparado em banho-maria para que asse de forma lenta e controlada, para atingir a textura ideal.&nbsp;<br />- Para que o seu pudim n&atilde;o forme furinhos, verifique se a temperatura do forno est&aacute; regulada conforme indica&ccedil;&atilde;o da receita. Leve a forma ao forno na grade superior, longe da chama.\r\n\r\n</div>\r\n\r\n', 27, '2018-07-30', '825067d64d7bc5de26fa31fdc0d93acb.jpg', 13),
(15, 'S', 'Receita de Pamonha', 'Pamonha Receita', '<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"http://s01.video.glbimg.com/x720/5913632.jpg\" alt=\"Resultado de imagem para pamonha\" width=\"480\" height=\"270\" /></p>\r\n<h3 class=\"ingredients-title box-title\"><img class=\"ico ingredients\" src=\"https://img.itdg.com.br/tdg/assets/layout/blank.gif\" />INGREDIENTES</h3>\r\n<ul>\r\n<li><span class=\"p-ingredient\">12 (doze) espigas de milho verde</span></li>\r\n<li><span class=\"p-ingredient\">1 (um) copo de &aacute;gua</span></li>\r\n<li><span class=\"p-ingredient\">2 (duas) x&iacute;caras de a&ccedil;&uacute;car</span></li>\r\n<li><span class=\"p-ingredient\">1 (uma) x&iacute;cara de coco ralado fino</span></li>\r\n<li><span class=\"p-ingredient\">1 (uma) pitada de sal</span></li>\r\n<li><span class=\"p-ingredient\">palhas para a embalagem</span></li>\r\n</ul>\r\n<div id=\"info-user-with-ads\" class=\"ingredients-info\">\r\n<div class=\"info-block ads\">\r\n<div id=\"ad-mpu2\" class=\"\" data-mad-adunit=\"/21636860837/TudoGostosoDesktop/Content\" data-mad-auto-refresh-in-seconds=\"30\" data-mad-auto-refresh-limit=\"999\" data-mad-lazyload-offset=\"300\" data-mad-size=\"[[300,250]]\" data-mad=\"\">&nbsp;</div>\r\n</div>\r\n<div class=\"info-block info-user\">\r\n<h3 class=\"directions-title box-title\">MODO DE PREPARO</h3>\r\n<div class=\"instructions e-instructions\">\r\n<ol>\r\n<li>Rale as espigas ou corte-as rente ao sabugo e passe no liquidificador, juntamente com a &aacute;gua</li>\r\n<li>Acrescente o coco, o a&ccedil;&uacute;car e mexa bem</li>\r\n<li>Coloque a massa na palha de milho e amarre bem</li>\r\n<li>Em uma panela grande ferva bem a &aacute;gua, e v&aacute; colocando as pamonhas uma a uma ap&oacute;s a fervura completa da &aacute;gua</li>\r\n<li>Importante : a &aacute;gua deve estar realmente fervendo para receber as pamonhas, caso contr&aacute;rio elas v&atilde;o se desfazer</li>\r\n<li>Cozinhe por mais ou menos 40 minutos, retirando as pamonhas com o aux&iacute;lio de uma escumadeira</li>\r\n<li>Deixe esfriar em local bem fresco</li>\r\n<li>Sirva com caf&eacute; e qu', 27, '2018-07-31', '618496677f07b623bec948aa8e420c66.jpg', 11);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `idUsuario` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `idGrupo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`idUsuario`, `nome`, `login`, `senha`, `foto`, `idGrupo`) VALUES
(16, 'teste12', 'test123', '12345678', '', 2),
(26, 'joao', 'leal', '12345678', '', 2),
(27, 'victor', 'victorsouza02', '10021997', '70f9dcb1980f501783e1b724196119dc.jpg', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `grupo`
--
ALTER TABLE `grupo`
  ADD PRIMARY KEY (`idGrupo`);

--
-- Indexes for table `postagem`
--
ALTER TABLE `postagem`
  ADD PRIMARY KEY (`idPostagem`),
  ADD KEY `idUsuario` (`idUsuario`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`idUsuario`),
  ADD KEY `idGrupo` (`idGrupo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `grupo`
--
ALTER TABLE `grupo`
  MODIFY `idGrupo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `postagem`
--
ALTER TABLE `postagem`
  MODIFY `idPostagem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idUsuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `postagem`
--
ALTER TABLE `postagem`
  ADD CONSTRAINT `postagem_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`);

--
-- Limitadores para a tabela `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`idGrupo`) REFERENCES `grupo` (`idGrupo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
